#include "sendsession.h"
#include "protocol.h"

#include <QDebug>
#include <QFileInfo>
#include <QJsonObject>
#include <QJsonDocument>
#include <QtEndian>

// SendSession constructor
SendSession :: SendSession (const QString &host, quint16 port, const QString &filePath, QObject *parent) : QObject(parent), socket(new QTcpSocket(this)), filePath(filePath)
{
    connect(socket, &QTcpSocket :: connected, this, &SendSession :: onConnected);
    connect(socket, &QTcpSocket :: disconnected, this, &SendSession :: onDisconnected);
    connect(socket, &QTcpSocket :: errorOccurred, this, &SendSession :: onSocketError);
    connect(socket, &QTcpSocket :: bytesWritten, this, &SendSession :: sendMore);
    connect(socket, &QTcpSocket :: readyRead, this, &SendSession :: onReadyRead);

    qDebug() << "Sender session: connecting to: " << host << port;
    socket -> connectToHost(host, port);
}

SendSession :: ~SendSession()
{
    qDebug() << "Sender session destroyed";
}

void SendSession :: onConnected()
{
    const QFileInfo info(filePath); // gets the path's info

    if (!info.exists() || !info.isFile()) { // checks if the path exist and points to a file rather than a directory
        qDebug() << "Sender Session file not found: " << filePath;
        socket -> disconnectFromHost();
        return;
    }

    file = new QFile(filePath, this);
    if (!file -> open(QIODevice :: ReadOnly)) { // checkes if the file has Read access
        qDebug() << "Sender session cannot open this file: " << file -> fileName() << " error: " << file -> errorString();
        delete file;
        file = nullptr; // when the condition fails, we are reinitializing file to point towards nullptr and disconnect
        socket -> disconnectFromHost();
        return;
    }

    totalSize = file -> size(); // update totalSize with the file's size in bytes

    // creating the JSON header as part of the protocol, with all it's fields
    QJsonObject header;
    header["v"] = currentVersionNumber;
    header["type"] = "file";
    header["filename"] = info.fileName();
    header["size"] = totalSize;

    // converts the header into JSON (text) and removes unnecessary spaces and lines to make it 'compact'
    const QByteArray json = QJsonDocument(header).toJson(QJsonDocument :: Compact);

    QByteArray frame(4, '\0'); // creates an empty byte array of set of 4 bytes, all '00'
    qToBigEndian<quint32>(static_cast<quint32>(json.size()), frame.data()); // adds the json.size() as quint32 type into frame array
    frame.append(json); // appends json with frame

    qDebug() << "Sender session sending header: " << info.fileName() << " size " <<info.size();
    socket -> write(frame); // writes the frame onto the connected session socket

    sendMore(); // after writing, make signal to send more bytes to fill the queue
}

void SendSession :: onDisconnected()
{
    if (!gotReply) { // checking if we changed gotReply to true in any process
        qDebug() << "Sender session disconnected before reply; transfer failed";
    }

    qDebug() << "Sender session disconnected";
    deleteLater();
}

void SendSession :: onSocketError(QAbstractSocket :: SocketError)
{
    qDebug() << "Sender session socket error: " << socket -> errorString();
}

void SendSession :: sendMore()
{
    if (!file) {
        return;
    }

    while (sentSize < totalSize && socket -> bytesToWrite() < maxQueuedBytes) { // checks whether there are bytes to transfer and if there is any space within the limit for more bytes
        const QByteArray chunk = file -> read (qMin (chunkSize, totalSize - sentSize)); // slice or partition of data of either defined size (chunkSize) or if only less bytes are available, then the remaining bytes

        if(chunk.isEmpty()) { // if the chunk of data is empty, it means there is no data to partition - signalling session break or unreadable file
            file -> close();
            delete file;
            file = nullptr;

            fail("Sender session file ended early or could not be read");

            socket -> disconnectFromHost();
            return;
        }

        socket -> write(chunk); // write chunk onto the socket
        sentSize += chunk.size(); // update sent size after writing
    }

    if (sentSize == totalSize) {
        qDebug() << "Send session all " << sentSize << " bytes queued";
        file -> close();
        delete file;
        file = nullptr;
    }

    // we tell how much bytes left the socket by finding (sent bytes - still waiting in queue bytes)
    emit progress(fileName, qMax<qint64> (0, sentSize - socket -> bytesToWrite()), totalSize);

}

// activates whenever there is any bytes on the buffer
void SendSession :: onReadyRead()
{

    if (gotReply) { // exactly one reply per session
        return;
    }

    receivedBuffer.append(socket -> readAll());

    if (receivedBuffer.size() < 4) { // length prefix not yet arrived
        return;
    }

    const quint32 length = qFromBigEndian<quint32>(receivedBuffer.constData()); // basically it decodes from the header prefix for the length of the JSON text reply

    if (length == 0 || length > 16384) { // to remain within 0 - 16384
        qDebug() << "Sender session invalid reply length: " << length;
        socket -> disconnectFromHost();
        return;
    }

    if (receivedBuffer.size() < static_cast<qsizetype>(length + 4) ) { // to account for the header prefix and the reply length
        return;
    }

    QJsonParseError error;
    const QJsonDocument document = QJsonDocument :: fromJson(receivedBuffer.mid(4, length), &error); // parses bytes into JSON document and handling errors

    if (error.error != QJsonParseError :: NoError || !document.isObject()) {
        qDebug() << "Sender session invalid reply error: " << error.errorString();
        socket -> disconnectFromHost();
        return;
    }

    QJsonObject reply = document.object(); // converting the JSON document into JSON object for readability

    const Protocol :: decodeStatus status = Protocol :: tryDecodeFrame(receivedBuffer, reply);

    if (status == Protocol :: decodeStatus :: NeedMoreData) {
        return;
    }

    if (status == Protocol :: decodeStatus :: Invalid) {
        fail("Invalid reply from receiver");
        socket -> disconnectFromHost();
        return;
    }

    gotReply = true; // changing to true since we got a reply from the receiver

    if(reply.value("status").toString() == "ok") { // checking the value of the reply code
        qDebug() << "Sender session transfer succeeded";
    }
    else {
        qDebug() << "Sender session transfer failed, code: " << reply.value("code").toString();
    }

    socket -> disconnectFromHost();
}

void SendSession :: fail(const QString &reason)
{
    if (reported) {
        return; // if the process is done, no need for declaring fail
    }

    reported = true;
    qDebug() << "Send session failed: " << reason;
    emit failed(fileName, reason);
}
